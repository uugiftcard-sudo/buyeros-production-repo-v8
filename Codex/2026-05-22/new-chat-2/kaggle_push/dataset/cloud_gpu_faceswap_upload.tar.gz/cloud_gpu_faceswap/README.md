# Cloud GPU Faceswap Test Bundle

This bundle prepares a short training-style faceswap test for a Linux NVIDIA GPU VM.

## Local Inputs

- `input/target_test_5s.mp4`: 5 second target clip for the first test render.
- `input/target_normalized.mp4`: full normalized target video for later use.
- `../source_faces/`: source identity photos copied from local inputs.

## Recommended VM

- Ubuntu 22.04 or 24.04
- NVIDIA GPU with at least 16 GB VRAM, preferably 24 GB
- CUDA-capable driver installed
- 100 GB free disk space

## Workflow

1. Run `bash scripts/00_make_upload_package.sh` locally and upload `cloud_gpu_faceswap_upload.tar.gz` to the VM.
2. On the VM, unpack with `tar -xzf cloud_gpu_faceswap_upload.tar.gz`.
3. Run `cd cloud_gpu_faceswap`.
4. Run `bash scripts/01_setup_faceswap.sh`.
5. Run `bash scripts/02_prepare_workspace.sh`.
6. Run `bash scripts/03_extract_faces.sh`.
7. Manually review and delete bad face crops in `workspace/source_faces_extract` and `workspace/target_faces_extract`.
8. Run `bash scripts/04_train_preview.sh`.
9. Run `bash scripts/05_convert_test.sh`.
10. Download `output/faceswap_test.mp4`.

## Current Limitation

There are only a few source images in the current local bundle. For a realistic identity match, add 15-30 source photos to `../source_faces/` before uploading.
