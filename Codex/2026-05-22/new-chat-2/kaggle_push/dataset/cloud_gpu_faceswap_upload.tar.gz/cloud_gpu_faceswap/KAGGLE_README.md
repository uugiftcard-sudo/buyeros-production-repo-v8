# Kaggle Free GPU Workflow

Use this when Colab is unstable or cannot upload files.

## Files

- `faceswap_kaggle.ipynb`
- `cloud_gpu_faceswap_upload.tar.gz`

## Steps

1. Open Kaggle Notebooks.
2. Create a new notebook and enable `GPU T4 x2` or `GPU P100`.
3. Enable `Internet` in notebook settings.
4. Add `cloud_gpu_faceswap_upload.tar.gz` as a Kaggle Dataset input.
5. Upload/import `faceswap_kaggle.ipynb`.
6. Run all cells.
7. Download `/kaggle/working/faceswap_output/faceswap_test.mp4` from the Output panel.

## Notes

Kaggle storage under `/kaggle/working` is temporary. Download the result before ending the session. If installation fails because Internet is disabled, turn Internet on and restart the notebook.
