# Free Google Colab Workflow

Use this when you do not have a paid Ubuntu GPU VM.

## Files to Upload

- `cloud_gpu_faceswap_upload.tar.gz`
- Optional: add more source photos to `source_faces/` first, then rerun `scripts/00_make_upload_package.sh`.

## Steps

1. Open Google Colab.
2. Upload `faceswap_free_colab.ipynb`.
3. In Colab, set `Runtime > Change runtime type > T4 GPU`.
4. Run the cells from top to bottom.
5. When prompted, upload `cloud_gpu_faceswap_upload.tar.gz`.
6. After extraction, inspect the generated face contact sheets.
7. Run training and conversion cells.
8. Download `faceswap_test.mp4`.

## Limitations

Colab Free can disconnect or lose local files. The notebook saves checkpoints under `/content/faceswap_work` during the session, but you should download results quickly. For longer training, mount Google Drive in the notebook and copy `workspace/model` there.
